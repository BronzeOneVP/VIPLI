﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi
{
    public partial class ExperienceScreen : Form
    {
        // Declare Variable
        int experience;
        
        public ExperienceScreen()
        {
            //Maximizes window to full screen
            this.WindowState = FormWindowState.Maximized;
            InitializeComponent();
        }

        private void TransitionWindow(int experience)
        {
            // Transitions to StartingStrengthScreen
            StartingStrengthScreen newForm = new StartingStrengthScreen(experience);
            newForm.Show();
            this.Hide();
        }
        
        // Experience lvl of user is assigned to int epxerience variable based on button click and then calls TransitionWindow function
        private void Beginner(object sender, EventArgs e)
        {
            experience = 0;
            TransitionWindow(experience);
        }

        private void Novice(object sender, EventArgs e)
        {
            experience = 1;
            TransitionWindow(experience);
        }

        private void Intermediate(object sender, EventArgs e)
        {
            experience = 2;
            TransitionWindow(experience);
        }

        private void Advanced(object sender, EventArgs e)
        {
            experience = 3;
            TransitionWindow(experience);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ExperienceScreen_Load(object sender, EventArgs e)
        {

        }
    }
}
