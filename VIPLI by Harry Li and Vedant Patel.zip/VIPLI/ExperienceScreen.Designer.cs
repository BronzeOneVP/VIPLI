﻿namespace Hi
{
    partial class ExperienceScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExperienceScreen));
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 45F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(-89, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1534, 192);
            this.label1.TabIndex = 1;
            this.label1.Text = "How much training experience do you have?";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button4
            // 
            this.button4.AutoSize = true;
            this.button4.BackColor = System.Drawing.Color.Red;
            this.button4.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 60F);
            this.button4.Location = new System.Drawing.Point(707, 219);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(500, 279);
            this.button4.TabIndex = 8;
            this.button4.Text = "Novice\r\n";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.Novice);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Red;
            this.button3.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 60F);
            this.button3.Location = new System.Drawing.Point(156, 535);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(500, 279);
            this.button3.TabIndex = 7;
            this.button3.Text = "Intermediate";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.Intermediate);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 60F);
            this.button2.Location = new System.Drawing.Point(707, 535);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(500, 279);
            this.button2.TabIndex = 6;
            this.button2.Text = "Advanced";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Advanced);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Red;
            this.label2.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 20F);
            this.label2.Location = new System.Drawing.Point(261, 422);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(284, 41);
            this.label2.TabIndex = 9;
            this.label2.Text = "Never trained before";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Red;
            this.button5.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 60F);
            this.button5.Location = new System.Drawing.Point(156, 219);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(500, 279);
            this.button5.TabIndex = 5;
            this.button5.Text = "Beginner";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.Beginner);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Red;
            this.label3.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 20F);
            this.label3.Location = new System.Drawing.Point(773, 411);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(391, 62);
            this.label3.TabIndex = 10;
            this.label3.Text = "0-1 years of training";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Red;
            this.label4.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 20F);
            this.label4.Location = new System.Drawing.Point(773, 728);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(367, 56);
            this.label4.TabIndex = 11;
            this.label4.Text = "3+ years of training";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Red;
            this.label5.Font = new System.Drawing.Font("Tw Cen MT Condensed Extra Bold", 20F);
            this.label5.Location = new System.Drawing.Point(210, 728);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(379, 56);
            this.label5.TabIndex = 12;
            this.label5.Text = "1-3 years of training";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ExperienceScreen
            // 
            this.ClientSize = new System.Drawing.Size(1342, 841);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ExperienceScreen";
            this.Load += new System.EventHandler(this.ExperienceScreen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

