﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi
{
    public partial class GoalsScreen : Form
    {
        /*
         * This form decides which workout plan to open based on the previously determined 
         * difficulty and the goal from this form
        */
        
        // Declare variables
        int difficulty;

        public GoalsScreen(int myDifficulty)
        {
            this.WindowState = FormWindowState.Maximized;
            InitializeComponent();
            difficulty = myDifficulty;
        }

        // Goal of user is to build muscle. Assigns excercise plan to user based on strength and experience lvl 
        private void BuildMuscle(object sender, EventArgs e)
        {
            if (difficulty == 0)
            {
                EasyBuildMuscle newForm = new EasyBuildMuscle();
                newForm.Show();
                this.Hide();
            }

            if (difficulty == 1)
            {
                MedBuildMuscle newForm = new MedBuildMuscle();
                newForm.Show();
                this.Hide();
            }

            if (difficulty == 2)
            {
                HardBuildMuscle newForm = new HardBuildMuscle();
                newForm.Show();
                this.Hide();
            }
        }

        // Goal of user is to gain strength. Assigns excercise plan to user based on strength and experience lvl 
        private void GainStrength(object sender, EventArgs e)
        {
            if (difficulty == 0)
            {
                EasyGainStrength newForm = new EasyGainStrength();
                newForm.Show();
                this.Hide();
            }

            if (difficulty == 1)
            {
                MedGainStrength newForm = new MedGainStrength();
                newForm.Show();
                this.Hide();
            }

            if (difficulty == 2)
            {
                HardGainStrength newForm = new HardGainStrength();
                newForm.Show();
                this.Hide();
            }

        }

        // Goal of user is to lose weight. Assigns excercise plan to user based on strength and experience lvl
        private void LoseWeight(object sender, EventArgs e)
        {
            if (difficulty == 0)
            {
                EasyLoseWeight newForm = new EasyLoseWeight();
                newForm.Show();
                this.Hide();
            }

            if (difficulty == 1)
            {
                MedLoseWeight newForm = new MedLoseWeight();
                newForm.Show();
                this.Hide();
            }

            if (difficulty == 2)
            {
                HardLoseWeight newForm = new HardLoseWeight();
                newForm.Show();
                this.Hide();
            }

        }

        // Goal of user is to increase sport performance. Assigns excercise plan to user based on strength and experience lvl 
        private void IncreaseSportsPerformance(object sender, EventArgs e)
        {
            if (difficulty == 0)
            {
                EasySports newForm = new EasySports();
                newForm.Show();
                this.Hide();
            }

            if (difficulty == 1)
            {
                MedSports newForm = new MedSports();
                newForm.Show();
                this.Hide();
            }

            if (difficulty == 2)
            {
                HardSports newForm = new HardSports();
                newForm.Show();
                this.Hide();
            }
        }

        private void GoalsScreen_Load(object sender, EventArgs e)
        {

        }
    }
}
