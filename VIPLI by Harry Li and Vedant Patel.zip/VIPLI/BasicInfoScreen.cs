﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi
{
    
    public partial class BasicInfoScreen : Form
    {
        // Declare global variables
        public static string SetValueForText1 = "";
        public static string SetValueForText2 = "";
        public static string SetValueForText3 = "";
        public static string SetValueForText4 = "";

        public BasicInfoScreen()
        {
            // This Maximizes the window
            this.WindowState = FormWindowState.Maximized;
            InitializeComponent();
        }

        // text entry of user's name
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Name_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        //When the button is pressed, page transitions to ExperienceScreen and leaves current page
        private void button1_Click(object sender, EventArgs e)
        {
            // set global variables for name, age, height and weight
            SetValueForText1 = txtName.Text;
            SetValueForText2 = txtAge.Text;
            SetValueForText3 = txtHeight.Text;
            SetValueForText4 = txtWeight.Text;

            // Directs user to experience screen
            ExperienceScreen newForm = new ExperienceScreen();
            newForm.Show();
            Visible = false;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }


        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }


        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        // Function to make sure user enters a valid input for height
        private void txtHeight_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char chr = e.KeyChar;

            // If the key pressed is not a digit or not backspace, display a mesage box

            if (!Char.IsDigit(chr)&&chr!=8)
            {
                e.Handled = true;
                MessageBox.Show("Please enter a number");
            }
        }

        // Function to make sure user enters a valid input for height
        private void txtWeight_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char chr = e.KeyChar;

            // If the key pressed is not a digit or not backspace, display a mesage box
            if (!Char.IsDigit(chr) && chr != 8)
            {
                e.Handled = true;
                MessageBox.Show("Please enter a number");
            }
        }
    }
}
