﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi
{
    public partial class ProfileScreen : Form
    {
        public ProfileScreen()
        {
            // This Maximizes the window
            this.WindowState = FormWindowState.Maximized;
            InitializeComponent();
        }

        private void ProfileScreen_Load(object sender, EventArgs e)
        {
            // Declare variables
            double height;
            double weight;
            double bmiStep1;
            double bmi;
            string bmiStatus;
            string bmiGoalMessage;
            
            // Output the user values for name, age, height, and weight
            label1.Text = BasicInfoScreen.SetValueForText1;
            label1.ForeColor = System.Drawing.Color.Red;

            label2.Text = BasicInfoScreen.SetValueForText2;
            label2.ForeColor = System.Drawing.Color.Red;

            label3.Text = BasicInfoScreen.SetValueForText3;
            label3.ForeColor = System.Drawing.Color.Red;

            label4.Text = BasicInfoScreen.SetValueForText4;
            label4.ForeColor = System.Drawing.Color.Red;

            label7.ForeColor = System.Drawing.Color.Red;

            // Parse the height and weight
            height = double.Parse(BasicInfoScreen.SetValueForText3);
            weight = double.Parse(BasicInfoScreen.SetValueForText4);

            // Convert height to meters
            height = height / 100;

            // Step 1 of BMI calculation
            bmiStep1 = Math.Pow(height, 2);

            // Step 2 of BMI calculation
            bmi = weight / bmiStep1;

            // Output user bmi to one decimal
            label7.Text = String.Format("{0:##.#}", bmi);

            // Conditions to see which criteria user BMI falls under
            if (bmi < 18.5)
            {
                bmiStatus = "Underweight";
                bmiGoalMessage = "You should gain some weight to achieve a healthy weight\nWe reccomend the build muscle or strength program";
            }

            else if (bmi < 24.9)
            {
                bmiStatus = "Normal Weight";
                bmiGoalMessage = "Congratulations! You are at a healthy weight";
            }

            else if (bmi < 29.9)
            {
                bmiStatus = "Overweight";
                bmiGoalMessage = "You could lose some weight to achieve a healthy weight";
            }

            else
            {
                bmiStatus = "Obese";
                bmiGoalMessage = "You need to lose weight, your weight puts you at risk for chronic conditions\n We reccomend the fat loss program";
            }

            // Output the users bmi status and the message
            label12.Text = "You are " + bmiStatus;
            label13.Text = bmiGoalMessage;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        // On button click this restarts the quiz
        /*
        Pre: User clicks the restart button
        Post: Brings user back to start screen
        */
        private void restartButton_Click_1(object sender, EventArgs e)
        {
            StartScreen newForm = new StartScreen();
            newForm.Show();
            this.Hide();
        }

        // On button click go back to the users program
        private void backToWorkOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Program.profileForm.Show();
        }
    }
}
