﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi
{
    public partial class EasySports : Form
    {
        public EasySports()
        {
            this.WindowState = FormWindowState.Maximized;
            InitializeComponent();
        }

        private void Profile_Click(object sender, EventArgs e)
        {
            this.Hide();
            Program.profileForm = this;
            ProfileScreen profileScreen = new ProfileScreen();
            profileScreen.Show();
        }
    }
}
