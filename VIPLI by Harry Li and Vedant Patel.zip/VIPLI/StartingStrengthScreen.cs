﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi
{
    public partial class StartingStrengthScreen : Form
    {
        // Declare variable
        int theExperience;

        public StartingStrengthScreen(int experience)
        {
            // Maximize window
            this.WindowState = FormWindowState.Maximized;
            InitializeComponent();
            theExperience = experience;
        }

        // Transistions to next screen 
        private void TransitionWindow(int difficulty)
        {
            GoalsScreen newForm = new GoalsScreen(difficulty);
            newForm.Show();
            this.Hide();
        }

        /*
        Amount of pushups user can do is good indicator of general fitness/strength. 
        Here, pushups/starting strength is taken into consideration along with experience 
        to algorithmically calculate on what difficulty best suits the user.
        */
        private void zerotofive(object sender, EventArgs e)
        {
            int strength = 0;
            ExperienceAndStrength(strength, theExperience);
        }

        private void sixtoten(object sender, EventArgs e)
        {
            int strength = 1;
            ExperienceAndStrength(strength, theExperience);
        }

        private void eleventotwenty(object sender, EventArgs e)
        {
            int strength = 2;
            ExperienceAndStrength(strength, theExperience);
        }

        private void twentyonetothirty(object sender, EventArgs e)
        {
            int strength = 3;
            ExperienceAndStrength(strength, theExperience);
        }

        private void thirtyplus(object sender, EventArgs e)
        {
            int strength = 4;
            ExperienceAndStrength(strength, theExperience);
        }

        /*
        enum is embedded data type to assign words to the integer values to each level of difficulty. 
        Its to make the code clearer and simpler to understand

        easy = 0
        medium = 1
        hard = 2
        */
        enum diff
        {
            easy,
            medium,
            hard
        };    
        

        // 2d array designed to determine difficulty using the two factors of experience and starting strength.
        diff[,] DifficultyLvl = new diff[5, 4]

            {
                {diff.easy,diff.easy,diff.easy,diff.medium},
                {diff.easy,diff.easy,diff.medium,diff.medium},
                {diff.easy,diff.medium,diff.medium,diff.hard},
                {diff.medium,diff.medium,diff.hard,diff.hard},
                {diff.medium,diff.hard,diff.hard,diff.hard}
            };
        /* Pre: User clicks a button that assisigns the strength variable. We have the experience variable from before and we need these are required before the function
           Post: Assigns a difficulty to the varriable difficulty from the 2d array and then calls function TransitionWindow with argument difficulty
        */
        // This function accesses the array called DifficultyLvl
        private void ExperienceAndStrength (int strength, int theExperience)
        {
            // Assign the integer difficulty the result of acessing the array
           int difficulty = (int)DifficultyLvl[strength, theExperience];
           TransitionWindow(difficulty);
        }

        private void StartingStrengthScreen_Load(object sender, EventArgs e)
        {

        }
    }
}
