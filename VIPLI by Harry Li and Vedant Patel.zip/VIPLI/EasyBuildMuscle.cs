﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hi
{
    public partial class EasyBuildMuscle : Form
    {
        public EasyBuildMuscle()
        {
            // Maximize size of window
            this.WindowState = FormWindowState.Maximized;
            InitializeComponent();
        }

        private void Profile_Click(object sender, EventArgs e)
        {
            // Directs user back to profile screen
            this.Hide();
            Program.profileForm = this;
            ProfileScreen profileScreen = new ProfileScreen();
            profileScreen.Show();
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
